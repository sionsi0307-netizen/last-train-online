const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true } });
const PORT = process.env.PORT || 3000;
const rooms = new Map();
const MAX_ROOMS = 500;
const MAX_PLAYERS = 6;
const MIN_PLAYERS = 3;
const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const stations = [
  ["출발역","🚉","승객들이 마지막으로 명단에 오른 역이다."],
  ["폐쇄역","🌫️","폐쇄된 승강장. 이동할 때마다 보급이 필요하다."],
  ["검문역","🛂","승객의 신분을 확인하는 역이다."],
  ["터널역","🚇","통신이 끊기고 어둠이 길게 이어진다."],
  ["분기점","↗️","기관사의 판단에 따라 위험이 달라진다."],
  ["급수역","💧","식량과 보급품을 구할 수 있다."],
  ["무인역","🏚️","역무원은 없지만 안내 방송이 나온다."],
  ["정전역","⚡","불이 꺼진 동안 누구도 서로를 제대로 보지 못한다."],
  ["교량역","🌉","열차가 흔들리며 선로를 통과한다."],
  ["종착 전 역","🕰️","돌아갈 수 있는 마지막 기회다."],
  ["최종 검문","🔦","남은 승객들의 신분을 다시 확인한다."],
  ["종착역","🏁","열차가 도착하면 각자의 목적이 판정된다."]
];
const roleGoals = {
  "승객":"생존한 채 종착역에 도착한다.",
  "기관사":"열차를 파괴되지 않게 지켜 종착역에 도착한다.",
  "밀항자":"정체가 밝혀지지 않은 채 생존해 도착한다.",
  "방해꾼":"열차 손상을 3까지 올려 파괴한다."
};
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, rooms: rooms.size }));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

function code() {
  let out;
  do {
    out = Array.from({length:5}, () => CODE_CHARS[crypto.randomInt(CODE_CHARS.length)]).join("");
  } while (rooms.has(out));
  return out;
}
function safeName(raw) {
  return String(raw || "").trim().replace(/[<>]/g, "").slice(0, 16) || "승객";
}
function publicState(room, socketId) {
  const me = room.players.find(p => p.id === socketId);
  return {
    code: room.code, hostId: room.hostId, phase: room.phase, round: room.round,
    maxPlayers: MAX_PLAYERS, minPlayers: MIN_PLAYERS,
    players: room.players.map(p => ({
      id:p.id, name:p.name, avatar:p.avatar, isHost:p.id===room.hostId,
      isMe:p.id===socketId, connected:p.connected, alive:p.alive,
      hp:p.hp, food:p.food, clues:p.clues,
      role: (p.id===socketId || p.roleRevealed) ? p.role : null,
      roleRevealed: !!p.roleRevealed,
      ready: !!p.ready
    })),
    myRole: me ? me.role : null, myGoal: me ? roleGoals[me.role] : null,
    station: room.round >= 0 ? stations[Math.min(room.round, 11)] : null,
    event: room.event, damage: room.damage, logs: room.logs.slice(-35),
    acted: !!(me && me.acted), vote: room.vote ? {
      eligible: room.vote.eligible.includes(socketId),
      submitted: room.vote.submitted.includes(socketId),
      counts: room.vote.revealed ? room.vote.counts : null,
      revealed: room.vote.revealed
    } : null,
    winner: room.winner
  };
}
function broadcast(room) {
  for (const p of room.players) io.to(p.id).emit("state", publicState(room, p.id));
}
function log(room, message, type="") {
  room.logs.push({ message, type, at: Date.now() });
  room.logs = room.logs.slice(-70);
}
function getPlayer(room, id) { return room.players.find(p => p.id === id); }
function errorTo(socket, message) { socket.emit("notice", {type:"error", message}); }
function makeRoles(n) {
  // At 3 players: passenger, stowaway, disruptor; at 4+: driver replaces an extra passenger.
  let roles = ["승객", "밀항자", "방해꾼"];
  if (n >= 4) roles.push("기관사");
  while (roles.length < n) roles.push("승객");
  for (let i=roles.length-1; i>0; i--) {
    const j = crypto.randomInt(i+1); [roles[i], roles[j]] = [roles[j], roles[i]];
  }
  return roles;
}
function startGame(room) {
  if (room.phase !== "lobby") return;
  if (room.players.length < MIN_PLAYERS) return;
  const roles = makeRoles(room.players.length);
  room.players.forEach((p,i) => {
    p.role = roles[i]; p.roleRevealed = false; p.hp=5; p.food=2; p.clues=0;
    p.alive=true; p.acted=false; p.ready=false;
  });
  room.round = 0; room.damage=0; room.phase="playing"; room.vote=null; room.winner=null;
  room.event = { title:"출발역", desc:"열차가 출발했다. 각자의 신분은 비밀이다. 행동을 선택하고 서로를 살펴라.", type:"STATION 01" };
  log(room, `열차가 출발했다. 탑승자 ${room.players.length}명.`);
  broadcast(room);
}
function alivePlayers(room) { return room.players.filter(p=>p.alive); }
function finish(room, reason) {
  if (room.phase === "ended") return;
  room.phase="ended";
  const winners = room.players.filter(p => {
    if (reason==="파괴") return p.role==="방해꾼";
    if (reason==="탈락") return false;
    if (!p.alive) return false;
    if (p.role==="방해꾼") return false;
    if (p.role==="밀항자" && p.roleRevealed) return false;
    return true;
  }).map(p=>({id:p.id,name:p.name,role:p.role}));
  room.winner={reason, winners};
  room.players.forEach(p=>{p.roleRevealed=true;});
  log(room, reason==="도착" ? "종착역에 도착했다. 승리 조건을 판정한다." : `게임 종료: ${reason}.`);
  broadcast(room);
}
function applyEvent(room) {
  const s=stations[room.round];
  let desc=s[2];
  if (room.round===1 || room.round===9) {
    for (const p of alivePlayers(room)) { if(p.food>0)p.food--; else p.hp--; }
    desc += " 모든 생존자는 식량 1개를 소비했다. 식량이 없으면 체력이 감소한다.";
  } else if (room.round===2 || room.round===10) {
    const unknown=alivePlayers(room).filter(p=>!p.roleRevealed);
    if(unknown.length) {
      const p=unknown[crypto.randomInt(unknown.length)];
      p.roleRevealed=true;
      desc += ` 검문 결과 ${p.name}의 신분이 공개되었다.`;
      log(room, `검문 결과: ${p.name} — ${p.role}`, "alert");
    } else desc += " 확인할 신분이 남아 있지 않다.";
  } else if (room.round===4) {
    if(Math.random()<0.35){room.damage++;desc+=" 선로 이상으로 열차가 손상됐다.";}
    else {const p=alivePlayers(room)[crypto.randomInt(alivePlayers(room).length)];if(p)p.clues++;desc+=" 선로에서 단서를 발견했다.";}
  } else if (room.round===5) {
    const p=alivePlayers(room)[crypto.randomInt(alivePlayers(room).length)];
    if(p){p.food+=2;desc+=` ${p.name}이 보급품 2개를 확보했다.`;}
  } else if (room.round===6) {
    const p=alivePlayers(room)[crypto.randomInt(alivePlayers(room).length)];
    if(p){p.clues++;desc+=" 역무실에서 단서를 발견했다.";}
  } else if (room.round===7) {
    for(const p of alivePlayers(room)) if(Math.random()<0.2)p.hp--;
    desc+=" 정전 중 소란이 일어났다.";
  } else if (room.round===8 && Math.random()<0.35) {
    room.damage++; desc+=" 열차가 흔들리며 손상됐다.";
  } else if (room.round===11) {
    desc+=" 종착역에 도착했다.";
  }
  room.event={title:s[0],desc,type:`STATION ${String(room.round+1).padStart(2,"0")}`};
  log(room, `${s[0]} 도착. ${desc}`);
}
function checkEnd(room) {
  if(room.damage>=3){finish(room,"파괴");return true;}
  for(const p of room.players) if(p.alive && p.hp<=0){p.hp=0;p.alive=false;p.roleRevealed=true;log(room,`${p.name}이 탈락했다.`,"alert");}
  if(!alivePlayers(room).length){finish(room,"전원 탈락");return true;}
  return false;
}
function resolveVotes(room) {
  const v=room.vote;
  if(!v || v.revealed) return;
  if(v.submitted.length < v.eligible.length) return;
  const counts={};
  for(const target of Object.values(v.votes)) counts[target]=(counts[target]||0)+1;
  const max=Math.max(0,...Object.values(counts));
  const top=Object.keys(counts).filter(k=>counts[k]===max && max>0);
  v.counts=counts;v.revealed=true;
  if(top.length===1){
    const target=room.players.find(p=>p.id===top[0]);
    if(target){target.roleRevealed=true;log(room,`투표 결과: ${target.name}의 신분은 '${target.role}'이다.`,"alert");room.event={title:"투표 결과",desc:`${target.name}의 신분은 '${target.role}'로 확인됐다.`,type:"VOTE RESULT"};}
  } else log(room,"투표가 동률로 끝났다. 아무도 검사받지 않았다.");
  broadcast(room);
}
io.on("connection", socket => {
  socket.on("createRoom", ({name}={}) => {
    if(rooms.size>=MAX_ROOMS){errorTo(socket,"현재 생성 가능한 방이 가득 찼습니다.");return;}
    const roomCode=code();
    const p={id:socket.id,name:safeName(name),avatar:["🧑","🧢","👩","🧥","🧔","👩‍🦱"][crypto.randomInt(6)],role:null,roleRevealed:false,hp:5,food:2,clues:0,alive:true,connected:true,acted:false,ready:false};
    const room={code:roomCode,hostId:socket.id,players:[p],phase:"lobby",round:-1,damage:0,event:null,logs:[],vote:null,winner:null};
    rooms.set(roomCode,room);socket.join(roomCode);socket.data.roomCode=roomCode;
    log(room,`${p.name}이 방을 만들었다.`);
    socket.emit("joined",{code:roomCode,id:socket.id});broadcast(room);
  });
  socket.on("joinRoom", ({code:rawCode,name}={}) => {
    const c=String(rawCode||"").toUpperCase().replace(/[^A-Z0-9]/g,"");
    const room=rooms.get(c);
    if(!room){errorTo(socket,"방 코드를 찾을 수 없습니다.");return;}
    if(room.phase!=="lobby"){errorTo(socket,"이미 게임이 시작된 방입니다.");return;}
    if(room.players.length>=MAX_PLAYERS){errorTo(socket,"방 인원이 가득 찼습니다.");return;}
    const p={id:socket.id,name:safeName(name),avatar:["🧑","🧢","👩","🧥","🧔","👩‍🦱"][crypto.randomInt(6)],role:null,roleRevealed:false,hp:5,food:2,clues:0,alive:true,connected:true,acted:false,ready:false};
    room.players.push(p);socket.join(c);socket.data.roomCode=c;
    socket.emit("joined",{code:c,id:socket.id});log(room,`${p.name}이 방에 참가했다.`);broadcast(room);
  });
  socket.on("startGame",()=>{
    const room=rooms.get(socket.data.roomCode);if(!room)return;
    if(room.hostId!==socket.id){errorTo(socket,"방장만 게임을 시작할 수 있습니다.");return;}
    if(room.players.length<MIN_PLAYERS){errorTo(socket,"최소 3명이 모여야 시작할 수 있습니다.");return;}
    startGame(room);
  });
  socket.on("action",({action,targetId}={})=>{
    const room=rooms.get(socket.data.roomCode);if(!room||room.phase!=="playing")return;
    const p=getPlayer(room,socket.id);if(!p||!p.alive)return;
    if(p.acted && action!=="vote"){errorTo(socket,"이번 역에서 이미 행동했습니다.");return;}
    if(room.vote && !room.vote.revealed && action!=="vote"){errorTo(socket,"투표가 진행 중입니다. 투표를 마쳐 주세요.");return;}
    if(action==="explore"){
      if(Math.random()<0.6){p.food++;log(room,`${p.name}이 탐색해 식량 1개를 얻었다.`);}
      else {p.clues++;log(room,`${p.name}이 탐색해 단서 1개를 얻었다.`);}
    } else if(action==="rest"){
      if(p.hp>=5){errorTo(socket,"체력이 이미 가득 찼습니다.");return;}
      p.hp++;log(room,`${p.name}이 휴식해 체력을 회복했다.`);
    } else if(action==="investigate"){
      if(p.clues<1){errorTo(socket,"조사에는 단서 1개가 필요합니다.");return;}
      const target=room.players.find(x=>x.id===targetId&&x.alive&&x.id!==p.id);
      if(!target){errorTo(socket,"조사할 플레이어를 선택하세요.");return;}
      p.clues--;target.roleRevealed=true;log(room,`${p.name}의 조사로 ${target.name}의 신분이 공개됐다.`,"alert");
      room.event={title:"조사 결과",desc:`${target.name}의 신분은 '${target.role}'이다.`,type:"INVESTIGATION"};
    } else if(action==="trade"){
      const target=room.players.find(x=>x.id===targetId&&x.alive&&x.id!==p.id);
      if(!target){errorTo(socket,"거래할 플레이어를 선택하세요.");return;}
      if(target.food<1){errorTo(socket,`${target.name}에게 식량이 없습니다.`);return;}
      if(p.food>=8){errorTo(socket,"식량을 더 보관할 수 없습니다.");return;}
      target.food--;p.food++;log(room,`${p.name}과 ${target.name}이 식량 1개를 거래했다.`);
    } else if(action==="repair"){
      if(room.damage>0){room.damage--;log(room,`${p.name}이 열차 손상 1을 수리했다.`);}
      else {p.clues++;log(room,`${p.name}이 점검 중 단서 1개를 발견했다.`);}
    } else if(action==="vote"){
      const target=room.players.find(x=>x.id===targetId&&x.alive&&x.id!==p.id);
      if(!target){errorTo(socket,"투표할 플레이어를 선택하세요.");return;}
      if(!room.vote||room.vote.revealed)room.vote={eligible:alivePlayers(room).filter(x=>!x.acted).map(x=>x.id),submitted:[],votes:{},counts:null,revealed:false};
      if(!room.vote.eligible.includes(p.id)){errorTo(socket,"이미 행동을 마쳐 이번 투표에 참여할 수 없습니다.");return;}
      if(room.vote.submitted.includes(p.id)){errorTo(socket,"이미 투표했습니다.");return;}
      room.vote.votes[p.id]=target.id;room.vote.submitted.push(p.id);p.acted=true;
      log(room,`${p.name}이 투표를 제출했다.`);
      resolveVotes(room);broadcast(room);return;
    } else {errorTo(socket,"알 수 없는 행동입니다.");return;}
    p.acted=true;
    if(checkEnd(room)){broadcast(room);return;}
    broadcast(room);
  });
  socket.on("nextStation",()=>{
    const room=rooms.get(socket.data.roomCode);if(!room||room.phase!=="playing")return;
    if(room.hostId!==socket.id){errorTo(socket,"방장만 다음 역으로 이동할 수 있습니다.");return;}
    const alive=alivePlayers(room);
    if(alive.some(p=>!p.acted)){errorTo(socket,"생존한 모든 플레이어가 행동을 마쳐야 이동할 수 있습니다.");return;}
    if(room.vote&&!room.vote.revealed){errorTo(socket,"모든 생존자가 투표를 마칠 때까지 기다리세요.");return;}
    if(room.round>=11){finish(room,"도착");return;}
    room.round++;
    room.players.forEach(p=>p.acted=false);
    room.vote=null;
    applyEvent(room);
    if(!checkEnd(room) && room.round===11){/* final station resolves on next host action */}
    broadcast(room);
  });
  socket.on("disconnect",()=>{
    const c=socket.data.roomCode;const room=rooms.get(c);if(!room)return;
    const p=getPlayer(room,socket.id);if(p){p.connected=false;log(room,`${p.name}의 연결이 끊어졌다.`,"alert");}
    // Keep the seat for a reconnect grace period; room will be cleaned up if everyone leaves.
    if(room.players.every(x=>!io.sockets.sockets.has(x.id))){
      setTimeout(()=>{const r=rooms.get(c);if(r&&r.players.every(x=>!io.sockets.sockets.has(x.id)))rooms.delete(c);},60000);
    }
    broadcast(room);
  });
});

server.listen(PORT, () => console.log(`마지막 열차 서버 실행 중: port ${PORT}`));
